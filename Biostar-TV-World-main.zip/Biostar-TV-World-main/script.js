const urls=[
"https://raw.githubusercontent.com/munim-sah75/Cofs_TV/refs/heads/main/fancode.m3u",
"https://raw.githubusercontent.com/biostartvworld/playlist/refs/heads/main/playlist.m3u",
"https://raw.githubusercontent.com/sm-monirulislam/RoarZone-Auto-Update-playlist/refs/heads/main/RoarZone.m3u"
]

let channels=[]
let activeCat="All"
let hls=null
let hideTimer=null
let levels=[]
let currentLevel=-1
let autoFromLink=false
let currentChannel=null

const list=document.getElementById("list")
const category=document.getElementById("category")
const left=document.getElementById("left")
const backBtn=document.getElementById("backBtn")
const video=document.getElementById("video")
const currentLogo=document.getElementById("currentLogo")
const currentName=document.getElementById("currentName")
const wrap=video.parentElement

video.controls=false
video.volume=1
video.muted=false
video.playsInline=true

function makeSlug(n){return n.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"")}
function getChannelFromURL(){return new URLSearchParams(location.search).get("id")}
function resetURL(){history.replaceState(null,"",location.pathname)}


const controlsBoard=document.createElement("div")
controlsBoard.style.cssText="position:absolute;left:0;right:0;bottom:0;pointer-events:none;display:flex;flex-direction:column;padding:6px 0;transition:.3s"
const controls=document.createElement("div")
controls.style.cssText="padding:6px 10px;display:flex;flex-direction:column;gap:6px;pointer-events:none"
const seek=document.createElement("input")
seek.type="range";seek.min=0;seek.max=100;seek.value=0
seek.style.cssText="width:100%;height:4px;appearance:none;border-radius:2px;pointer-events:auto;background:linear-gradient(to left,#444 0%,#ff0 0%)"
const row=document.createElement("div")
row.style.cssText="display:flex;justify-content:space-between;align-items:center;pointer-events:auto"
const leftControls=document.createElement("div")
leftControls.style.cssText="display:flex;gap:10px"

const play=document.createElement("button")
const stop=document.createElement("button")
const mute=document.createElement("button")
const vol=document.createElement("input")
const hd=document.createElement("button")
const share=document.createElement("button")
const fs=document.createElement("button")

play.innerHTML="▶"
stop.innerHTML="■"
mute.innerHTML="🔊"
hd.innerText="HD"
share.innerHTML="🔗"
fs.innerHTML="⛶"

;[play,stop,mute,hd,share,fs].forEach(b=>b.style.cssText="background:none;border:none;color:#ff0;font-size:16px;font-weight:bold;cursor:pointer")
vol.type="range";vol.min=0;vol.max=1;vol.step=.01;vol.value=1
vol.style.cssText="width:70px"

leftControls.append(play,stop)
const rightControls=document.createElement("div")
rightControls.style.cssText="display:flex;gap:10px;align-items:center"
rightControls.append(mute,vol,hd,share,fs)

row.append(leftControls,rightControls)
controls.append(seek,row)
controlsBoard.appendChild(controls)
wrap.appendChild(controlsBoard)

const loader=document.createElement("div")
loader.style.cssText="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);border:4px solid #444;border-top:4px solid #ff0;border-radius:50%;width:40px;height:40px;animation:spin 1s linear infinite;display:none;z-index:9"
wrap.appendChild(loader)

const style=document.createElement("style")
style.innerHTML="@keyframes spin{to{transform:translate(-50%,-50%) rotate(360deg)}}"
document.head.appendChild(style)

function showControls(){
controls.style.opacity=1
controlsBoard.style.background="rgba(0,0,0,.6)"
clearTimeout(hideTimer)
hideTimer=setTimeout(()=>{controls.style.opacity=0;controlsBoard.style.background="transparent"},3000)
}
wrap.onmousemove=wrap.onclick=wrap.ontouchstart=showControls

play.onclick=()=>{video.paused?(video.play(),play.innerHTML="⏸"):(video.pause(),play.innerHTML="▶")}
stop.onclick=()=>{video.pause();video.currentTime=0;play.innerHTML="▶"}
mute.onclick=()=>{video.muted=!video.muted;mute.innerHTML=video.muted?"🔇":"🔊"}
vol.oninput=e=>{video.volume=e.target.value;video.muted=false}
fs.onclick=()=>{document.fullscreenElement?document.exitFullscreen():wrap.requestFullscreen()}
share.onclick=()=>{if(!currentChannel)return;navigator.clipboard.writeText(location.origin+location.pathname+"?id="+currentChannel.id)}
hd.onclick=()=>{if(!hls||!levels.length)return;currentLevel++;if(currentLevel>=levels.length){hls.currentLevel=-1;hd.innerText="AUTO";currentLevel=-1}else{hls.currentLevel=levels[currentLevel].index;hd.innerText=levels[currentLevel].height+"p"}}

video.ontimeupdate=()=>{if(video.duration){seek.value=video.currentTime/video.duration*100;seek.style.background=`linear-gradient(to left,#444 ${seek.value}%,#ff0 ${seek.value}%)`}}
seek.oninput=e=>{if(video.duration)video.currentTime=e.target.value/100*video.duration}

function parseM3U(t){
t.split(/\r?\n/).forEach((l,i,a)=>{
if(l.startsWith("#EXTINF")){
const name=l.split(",").pop().trim()
const logo=(l.match(/tvg-logo="(.*?)"/)||[])[1]||""
const cat=(l.match(/group-title="(.*?)"/)||[])[1]||"Others"
const stream=(a[i+1]||"").trim()
const id=makeSlug(name)
if(stream.startsWith("http")&&!channels.some(c=>c.id===id)){
channels.push({name,logo,cat,stream,id})
}}})
}

function renderCategory(){
const cats=["All",...new Set(channels.map(c=>c.cat))]
category.innerHTML=""
cats.forEach(c=>{
const d=document.createElement("div")
d.className="catBtn"+(c===activeCat?" active":"")
d.innerText=c
d.onclick=()=>{activeCat=c;renderCategory();renderList(c==="All"?channels:channels.filter(x=>x.cat===c))}
category.appendChild(d)
})
}

function renderList(arr){
list.innerHTML=""
arr.forEach(c=>{
const d=document.createElement("div")
d.className="channelItem"
d.innerHTML=`<img src="${c.logo}">`
d.onclick=()=>playChannel(c,true)
list.appendChild(d)
})
}

function destroyPlayer(){if(hls){hls.destroy();hls=null}video.pause();video.removeAttribute("src");video.load()}

function startStream(url){
loader.style.display="block"
destroyPlayer()
if(video.canPlayType("application/vnd.apple.mpegurl")){
video.src=url
video.play()
video.oncanplay=()=>{loader.style.display="none";if(autoFromLink&&!document.fullscreenElement)wrap.requestFullscreen()}
}else if(Hls.isSupported()){
hls=new Hls()
hls.loadSource(url)
hls.attachMedia(video)
hls.on(Hls.Events.MANIFEST_PARSED,()=>{
levels=hls.levels.filter(l=>l.height).map((l,i)=>({...l,index:i}))
hls.currentLevel=-1
hd.innerText="AUTO"
video.play()
loader.style.display="none"
if(autoFromLink&&!document.fullscreenElement)wrap.requestFullscreen()
})
}
}

function playChannel(c,fromSite){
currentChannel=c
autoFromLink=!fromSite
if(getChannelFromURL()){list.style.display="none";category.style.display="none";backBtn.style.display="none"}else resetURL()
left.style.display="flex"
currentLogo.src=c.logo
currentName.innerText=c.name
startStream(c.stream)
showControls()
}

Promise.all(urls.map(u=>fetch(u).then(r=>r.text()).catch(()=>null))).then(r=>{
r.filter(Boolean).forEach(parseM3U)
renderCategory()
renderList(channels)

const cid=getChannelFromURL()
if(cid){
    document.querySelectorAll("body > *").forEach(e=>{
if(!e.contains(video)) e.style.display="none"
})
const wrap=video.parentElement
document.body.appendChild(wrap)
document.body.style.margin="0"
wrap.style.position="fixed"
wrap.style.inset="0"
wrap.style.width="100%"
wrap.style.height="100%"
wrap.style.background="#000"
    document.body.style.margin=0
document.getElementById("list").style.display="none"
document.getElementById("category").style.display="none"
document.getElementById("backBtn").style.display="none"
document.getElementById("left").style.display="none"

const ch=channels.find(x=>x.id===cid)
wrap.style.position="fixed"
wrap.style.inset="0"

video.muted=false
video.autoplay=true
setTimeout(()=>playChannel(ch,null,false),)
}
})
  
backBtn.onclick=()=>{video.pause();if(hls){hls.destroy();hls=null}left.style.display="none";backBtn.style.display="none"}


const timeBox=document.createElement("div")
timeBox.id="timeBox"
Object.assign(timeBox.style,{position:"absolute",top:"1px",right:"1px",background:"rgba(0,0,0,0.5)",color:"#fff",padding:"5px 9px",borderRadius:"10px",fontFamily:"Arial,sans-serif",fontSize:"7px",fontWeight:"bold",zIndex:"9999",whiteSpace:"nowrap",textAlign:"center"})
wrap.appendChild(timeBox)
setInterval(()=>{
const now=new Date();let hours=now.getHours();const minutes=now.getMinutes().toString().padStart(2,'0');const seconds=now.getSeconds().toString().padStart(2,'0');const ampm=hours>=12?'PM':'AM';hours=hours%12||12;const timeStr=`${hours.toString().padStart(2,'0')}:${minutes}:${seconds} ${ampm}`;const day=now.toLocaleDateString('en-US',{weekday:'long'});const date=now.toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric'});timeBox.innerText=`${timeStr} | ${day} | ${date}`
},1000)

const tg=document.createElement("a")
tg.href="https://t.me/biostartvworld"
tg.target="_blank"
tg.id="telegramChat"
tg.innerHTML=`<svg viewBox="0 0 24 24" width="26" height="26" fill="#fff"><path d="M9.04 15.84 8.7 19.6c.49 0 .7-.21.96-.46l2.3-2.2 4.77 3.49c.87.48 1.49.23 1.7-.8l3.08-14.44h0c.26-1.22-.44-1.7-1.28-1.39L1.62 9.2c-1.18.46-1.16 1.12-.2 1.42l4.7 1.47L17.4 5.9c.55-.36 1.06-.16.64.2"/></svg>`
Object.assign(tg.style,{position:"fixed",bottom:"20px",right:"20px",width:"52px",height:"52px",background:"#229ED9",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 4px 12px rgba(0,0,0,.3)",zIndex:"99999",textDecoration:"none"})
document.body.appendChild(tg)

if(typeof searchBtn!=='undefined' && typeof searchBox!=='undefined' && typeof searchInput!=='undefined'){
searchBtn.onclick=()=>{searchBox.style.display=searchBox.style.display==='block'?'none':'block';if(searchBox.style.display==='block') searchInput.focus()}
searchInput.addEventListener("keyup",()=>{const q=searchInput.value.trim().toLowerCase();const base=activeCat==='All'?channels:channels.filter(x=>x.cat===activeCat);renderList(q?base.filter(c=>c.name.toLowerCase().includes(q)):base)})
}

const icons=[play,stop,mute,hd,fs]
icons.forEach(icon=>{
icon.addEventListener("mouseenter",()=>{controlsBoard.style.background="rgba(0,0,0,0.6)";icon.style.color="#ff0"})
icon.addEventListener("mouseleave",()=>{controlsBoard.style.background="transparent";icon.style.color=(icon===hd||icon===mute||icon===live)?"yellow":"white"})
})

Promise.all(urls.map(u=>fetch(u).then(r=>r.text()).catch(()=>null))).then(r=>{r.filter(Boolean).forEach(parseM3U);renderCategory();renderList(channels)})
backBtn.onclick = () => { video.pause(); 
    if (hls) { hls.destroy(); 
        hls = null;
    } 
    left.style.display = "none"; 
    backBtn.style.display = "none"; }; 
    searchBtn.onclick = () => { searchBox.style.display = searchBox.style.display === "block" ? "none" : "block"; 
        if (searchBox.style.display === "block") searchInput.focus(); 

    };
document.addEventListener("contextmenu",e=>e.preventDefault())
document.addEventListener("keydown",e=>{
if(e.ctrlKey&&["u","s","c","p","x","i"].includes(e.key.toLowerCase()))e.preventDefault()
if(e.key==="F12")e.preventDefault()
if(e.ctrlKey&&e.shiftKey&&["i","j","c"].includes(e.key.toLowerCase()))e.preventDefault()
})

history.pushState(null,null,location.href)
window.onpopstate=()=>history.pushState(null,null,location.href)

if(/\.(m3u8?|txt)$/i.test(location.pathname)){
document.body.innerHTML=""
throw new Error() 
}